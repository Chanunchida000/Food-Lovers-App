package th.ac.su.ict.foodlovers.data

data class Foodlovers(
    val imageFile: String,
    val foodloversName: String,
    val caption: String,
    val description: String,
    val price: Int,
    val scariness: Int
)